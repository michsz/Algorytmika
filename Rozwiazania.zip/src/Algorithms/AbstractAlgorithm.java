package Algorithms;

public abstract class AbstractAlgorithm {

    public abstract String getName();
    public abstract void runAlgorithm(String[] input);
}
